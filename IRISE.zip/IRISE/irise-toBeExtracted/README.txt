********** How to install ***************
First, use (java 6 is required):

	java -jar extract2hsqlDB.jar
	
to generate databases that are necessary for the software to work properly.
98 hsql databases are then created into the folder databases (the size is huge around 9GB).

For information, IRISE raw data are stored into "data/" folder. These data have been collected into 98 hsql databases inside the "databases/" folder. 


********** How to get data **************

1) In order to extract data from IRISE, use (java 6 is required):

	java -jar extractValues.jar

Then select a household in between 2000900 and 2000997. 

Afterwards, choose a time interval using the format yyyy-MM-dd hh:mm:ss.0
Do not forget '0' ! For instance, 1998-02-29 01:00:23.0 is correct but not 1998-02-29 1:00:23.0

Data are saved into the folder csv/ inside 2 files "20009xx-values.csv" and "20009xx-states.csv" whose format is UTF8/Comma-Separated-Values. These files can be opened with a text editor or with OpenOffice Spreadsheet.

Values gather energy in Wh and states additional informations about device states.

For information, "extractValues.jar" use only hsql databases.

2) An additional CSV file can be generated: it gathers the list of all the households with the appliances inside. 
It is stored into the "csv/" folder with the name "appliances.csv". To get this file, use:

	java -jar generateAppliances.jar